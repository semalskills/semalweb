# Ajith Farm Shop - Design Style Guide

## Design Philosophy

**Theme**: Rustic Farm Elegance with Modern Sophistication
- Capture the authentic, wholesome feeling of fresh farm products
- Blend traditional farm aesthetics with contemporary web design
- Create trust and appetite appeal through visual storytelling
- Emphasize freshness, quality, and local community connection

## Color Palette

**Primary Colors**:
- Warm Earth Brown (#8B4513) - Rustic, natural, trustworthy
- Fresh Cream (#FFF8DC) - Clean, pure, appetizing
- Deep Forest Green (#2F4F2F) - Natural, fresh, organic

**Accent Colors**:
- Golden Harvest (#DAA520) - Warm, inviting, premium
- Soft Sage (#9CAF88) - Natural, calming, organic

**Text Colors**:
- Charcoal (#36454F) - Main text, high contrast
- Warm Gray (#696969) - Secondary text
- White (#FFFFFF) - Overlay text on dark backgrounds

## Typography

**Display Font**: Playfair Display (serif)
- Used for headings, hero text, brand name
- Conveys elegance, tradition, premium quality
- Large sizes for impact: 48px-72px for hero, 32px-48px for section headers

**Body Font**: Inter (sans-serif)
- Used for body text, navigation, product descriptions
- Clean, readable, modern
- Sizes: 16px-18px for body, 14px for captions

**Accent Font**: Caveat (handwritten)
- Used for special callouts, farm-fresh badges
- Adds personal, authentic touch

## Visual Language

**Imagery Style**:
- High-quality, natural lighting photography
- Warm, golden hour lighting preferred
- Focus on texture, freshness, and quality
- Real farm settings, authentic product shots
- No artificial filters or heavy processing

**Layout Principles**:
- Generous white space for breathing room
- Grid-based alignment for professional appearance
- Asymmetrical layouts for visual interest
- Content hierarchy through size and positioning

**Shape Language**:
- Organic curves and rounded corners
- Subtle farm-inspired elements (barn shapes, grain textures)
- Clean geometric forms for modern balance

## Visual Effects & Animation

**Used Libraries**:
- Anime.js: Smooth micro-interactions and page transitions
- ECharts.js: Order calculator visualizations
- Splide.js: Product image carousels
- p5.js: Subtle background particle effects

**Animation Style**:
- Gentle, organic movements (no harsh mechanical animations)
- Subtle hover effects with 3D depth
- Smooth scroll-triggered reveals
- Color transitions that evoke natural processes

**Background Effects**:
- Subtle grain texture overlay
- Gentle parallax scrolling for depth
- Warm gradient overlays on hero sections
- Floating particle effects suggesting freshness

## Component Styling

**Buttons**:
- Rounded corners (8px radius)
- Warm brown primary, sage green secondary
- Subtle drop shadows for depth
- Hover: Lift effect with increased shadow

**Cards**:
- Clean white backgrounds with soft shadows
- Rounded corners (12px radius)
- Hover: Gentle lift and shadow expansion
- Subtle border in sage green

**Forms**:
- Clean, minimal styling
- Warm accent colors for focus states
- Generous padding for touch-friendly interaction
- Clear validation feedback

**Navigation**:
- Fixed header with subtle transparency
- Warm brown background with white text
- Smooth hover transitions
- Mobile-first responsive design

## Accessibility & Contrast

- All text maintains 4.5:1 contrast ratio minimum
- Focus indicators clearly visible
- Color is never the only way to convey information
- Touch targets minimum 44px for mobile accessibility

## Brand Personality

**Authentic**: Real farm imagery, honest pricing, genuine testimonials
**Fresh**: Bright, clean visuals, emphasis on daily delivery
**Trustworthy**: Professional layout, clear contact info, quality guarantees
**Community-focused**: Local imagery, personal stories, neighborhood connection