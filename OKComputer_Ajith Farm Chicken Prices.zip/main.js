// Ajith Farm Shop - Main JavaScript
// Interactive functionality for farm shop website

// Product data with pricing
const products = {
    'skin-chicken': { name: 'Skin Chicken', price: 1200, image: 'https://kimi-web-img.moonshot.cn/img/themeatcornercalifornia.com/6b3f7fa4f89fc8059f0962ad0f65193f73ad1c31.jpg' },
    'skinless-chicken': { name: 'Skinless Chicken', price: 1150, image: 'https://kimi-web-img.moonshot.cn/img/media.istockphoto.com/646a6711a74f07199fb2192ba8d1a47c8427337e.jpg' },
    'gizzard': { name: 'Gizzard', price: 1400, image: 'https://kimi-web-img.moonshot.cn/img/deligoodph.com/9b666bd705c3fc72084a6bfa849ece945b84dd89.jpg' },
    'liver': { name: 'Liver', price: 1200, image: 'https://kimi-web-img.moonshot.cn/img/deligoodph.com/9b666bd705c3fc72084a6bfa849ece945b84dd89.jpg' },
    'drumstick': { name: 'Drumstick', price: 1400, image: 'https://kimi-web-img.moonshot.cn/img/d14fky00evb1ot.cloudfront.net/434a3d2d8f51b8f7cd2545add27789dcc7fb500f.webp' },
    'breast': { name: 'Chicken Breast', price: 1500, image: 'https://kimi-web-img.moonshot.cn/img/thumbs.dreamstime.com/11cd1fba1e23f697b199520206f1e3a98ad96ff1.jpg' }
};

// Shopping cart functionality
let cart = JSON.parse(localStorage.getItem('ajithFarmCart')) || {};

// Initialize application
document.addEventListener('DOMContentLoaded', function() {
    initializeAnimations();
    initializeOrderCalculator();
    initializeContactForm();
    initializeScrollEffects();
    initializeImageGalleries();
    updateCartDisplay();
});

// Animation initialization using Anime.js
function initializeAnimations() {
    // Hero text animation
    if (document.querySelector('.hero-title')) {
        anime({
            targets: '.hero-title',
            translateY: [50, 0],
            opacity: [0, 1],
            duration: 1000,
            easing: 'easeOutExpo',
            delay: 300
        });
    }

    // Product cards stagger animation
    if (document.querySelectorAll('.product-card').length > 0) {
        anime({
            targets: '.product-card',
            translateY: [30, 0],
            opacity: [0, 1],
            duration: 800,
            delay: anime.stagger(100),
            easing: 'easeOutExpo'
        });
    }

    // Floating elements animation
    anime({
        targets: '.floating-element',
        translateY: [-10, 10],
        duration: 3000,
        direction: 'alternate',
        loop: true,
        easing: 'easeInOutSine'
    });
}

// Order calculator functionality
function initializeOrderCalculator() {
    const calculatorContainer = document.getElementById('order-calculator');
    if (!calculatorContainer) return;

    // Create product selector interface
    const productGrid = document.createElement('div');
    productGrid.className = 'grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6 mb-8';
    
    Object.keys(products).forEach(productId => {
        const product = products[productId];
        const productCard = createProductCard(productId, product);
        productGrid.appendChild(productCard);
    });
    
    calculatorContainer.appendChild(productGrid);
    
    // Create order summary
    const summaryContainer = document.createElement('div');
    summaryContainer.id = 'order-summary';
    summaryContainer.className = 'bg-white rounded-lg shadow-lg p-6 mt-8';
    summaryContainer.innerHTML = `
        <h3 class="text-2xl font-bold text-amber-800 mb-4">Your Order</h3>
        <div id="order-items" class="space-y-2 mb-4"></div>
        <div class="border-t pt-4">
            <div class="flex justify-between items-center text-xl font-bold">
                <span>Total:</span>
                <span id="order-total">Rs. 0.00</span>
            </div>
        </div>
        <button id="proceed-order" class="w-full mt-6 bg-amber-600 hover:bg-amber-700 text-white font-bold py-3 px-6 rounded-lg transition-colors">
            Proceed to Order
        </button>
    `;
    
    calculatorContainer.appendChild(summaryContainer);
    
    // Add event listeners
    document.getElementById('proceed-order').addEventListener('click', proceedToOrder);
    
    updateOrderSummary();
}

function createProductCard(productId, product) {
    const card = document.createElement('div');
    card.className = 'product-card bg-white rounded-lg shadow-md overflow-hidden hover:shadow-lg transition-shadow';
    
    card.innerHTML = `
        <div class="relative">
            <img src="${product.image}" alt="${product.name}" class="w-full h-48 object-cover">
            <div class="absolute top-2 right-2 bg-amber-600 text-white px-2 py-1 rounded text-sm font-bold">
                Rs. ${product.price}/kg
            </div>
        </div>
        <div class="p-4">
            <h3 class="text-xl font-bold text-amber-800 mb-2">${product.name}</h3>
            <div class="flex items-center justify-between">
                <div class="flex items-center space-x-2">
                    <button class="quantity-btn bg-amber-100 hover:bg-amber-200 text-amber-800 w-8 h-8 rounded-full font-bold" 
                            onclick="updateQuantity('${productId}', -1)">-</button>
                    <span id="qty-${productId}" class="text-lg font-bold w-8 text-center">0</span>
                    <button class="quantity-btn bg-amber-100 hover:bg-amber-200 text-amber-800 w-8 h-8 rounded-full font-bold" 
                            onclick="updateQuantity('${productId}', 1)">+</button>
                </div>
                <span id="subtotal-${productId}" class="text-lg font-bold text-amber-600">Rs. 0</span>
            </div>
        </div>
    `;
    
    return card;
}

function updateQuantity(productId, change) {
    if (!cart[productId]) {
        cart[productId] = { quantity: 0 };
    }
    
    cart[productId].quantity = Math.max(0, cart[productId].quantity + change);
    
    if (cart[productId].quantity === 0) {
        delete cart[productId];
    }
    
    // Update display
    const qtyElement = document.getElementById(`qty-${productId}`);
    const subtotalElement = document.getElementById(`subtotal-${productId}`);
    
    if (qtyElement) {
        qtyElement.textContent = cart[productId] ? cart[productId].quantity : 0;
    }
    
    if (subtotalElement) {
        const subtotal = cart[productId] ? cart[productId].quantity * products[productId].price : 0;
        subtotalElement.textContent = `Rs. ${subtotal}`;
    }
    
    // Animate quantity change
    if (qtyElement) {
        anime({
            targets: qtyElement,
            scale: [1, 1.2, 1],
            duration: 300,
            easing: 'easeOutElastic(1, .8)'
        });
    }
    
    updateOrderSummary();
    saveCart();
}

function updateOrderSummary() {
    const orderItems = document.getElementById('order-items');
    const orderTotal = document.getElementById('order-total');
    
    if (!orderItems || !orderTotal) return;
    
    let total = 0;
    let html = '';
    
    Object.keys(cart).forEach(productId => {
        const product = products[productId];
        const quantity = cart[productId].quantity;
        const subtotal = quantity * product.price;
        total += subtotal;
        
        html += `
            <div class="flex justify-between items-center py-2">
                <span>${product.name} x ${quantity}kg</span>
                <span>Rs. ${subtotal}</span>
            </div>
        `;
    });
    
    if (html === '') {
        html = '<p class="text-gray-500">No items in your order yet.</p>';
    }
    
    orderItems.innerHTML = html;
    orderTotal.textContent = `Rs. ${total}`;
}

function proceedToOrder() {
    const hasItems = Object.keys(cart).length > 0;
    
    if (!hasItems) {
        showNotification('Please add some items to your order first!', 'warning');
        return;
    }
    
    // Store order data and redirect to contact page
    localStorage.setItem('pendingOrder', JSON.stringify(cart));
    window.location.href = 'contact.html';
}

function saveCart() {
    localStorage.setItem('ajithFarmCart', JSON.stringify(cart));
}

function updateCartDisplay() {
    // Update any cart quantity displays
    Object.keys(products).forEach(productId => {
        const qtyElement = document.getElementById(`qty-${productId}`);
        const subtotalElement = document.getElementById(`subtotal-${productId}`);
        
        if (qtyElement) {
            qtyElement.textContent = cart[productId] ? cart[productId].quantity : 0;
        }
        
        if (subtotalElement) {
            const subtotal = cart[productId] ? cart[productId].quantity * products[productId].price : 0;
            subtotalElement.textContent = `Rs. ${subtotal}`;
        }
    });
    
    updateOrderSummary();
}

// Contact form functionality
function initializeContactForm() {
    const contactForm = document.getElementById('contact-form');
    if (!contactForm) return;
    
    // Pre-fill form if there's a pending order
    const pendingOrder = JSON.parse(localStorage.getItem('pendingOrder'));
    if (pendingOrder) {
        const orderDetailsField = document.getElementById('order-details');
        if (orderDetailsField) {
            let orderText = 'Order Details:\n';
            Object.keys(pendingOrder).forEach(productId => {
                const product = products[productId];
                const quantity = pendingOrder[productId].quantity;
                orderText += `${product.name}: ${quantity}kg\n`;
            });
            orderDetailsField.value = orderText;
        }
    }
    
    contactForm.addEventListener('submit', handleContactSubmit);
}

function handleContactSubmit(e) {
    e.preventDefault();
    
    const formData = new FormData(e.target);
    const data = Object.fromEntries(formData);
    
    // Show loading state
    const submitBtn = e.target.querySelector('button[type="submit"]');
    const originalText = submitBtn.textContent;
    submitBtn.textContent = 'Sending...';
    submitBtn.disabled = true;
    
    // Simulate form submission
    setTimeout(() => {
        showNotification('Thank you for your order! We will contact you soon.', 'success');
        e.target.reset();
        
        // Clear pending order
        localStorage.removeItem('pendingOrder');
        localStorage.removeItem('ajithFarmCart');
        cart = {};
        
        // Reset button
        submitBtn.textContent = originalText;
        submitBtn.disabled = false;
        
        // Update displays
        updateCartDisplay();
    }, 2000);
}

// Scroll effects initialization
function initializeScrollEffects() {
    // Scroll-triggered animations
    const observerOptions = {
        threshold: 0.1,
        rootMargin: '0px 0px -50px 0px'
    };
    
    const observer = new IntersectionObserver((entries) => {
        entries.forEach(entry => {
            if (entry.isIntersecting) {
                const element = entry.target;
                
                if (element.classList.contains('fade-in-up')) {
                    anime({
                        targets: element,
                        translateY: [30, 0],
                        opacity: [0, 1],
                        duration: 800,
                        easing: 'easeOutExpo'
                    });
                }
                
                if (element.classList.contains('fade-in-left')) {
                    anime({
                        targets: element,
                        translateX: [-50, 0],
                        opacity: [0, 1],
                        duration: 800,
                        easing: 'easeOutExpo'
                    });
                }
                
                if (element.classList.contains('fade-in-right')) {
                    anime({
                        targets: element,
                        translateX: [50, 0],
                        opacity: [0, 1],
                        duration: 800,
                        easing: 'easeOutExpo'
                    });
                }
                
                observer.unobserve(element);
            }
        });
    }, observerOptions);
    
    // Observe elements with scroll animations
    document.querySelectorAll('.fade-in-up, .fade-in-left, .fade-in-right').forEach(el => {
        observer.observe(el);
    });
}

// Image gallery functionality
function initializeImageGalleries() {
    // Product image hover effects
    document.querySelectorAll('.product-image').forEach(img => {
        img.addEventListener('mouseenter', function() {
            anime({
                targets: this,
                scale: 1.05,
                duration: 300,
                easing: 'easeOutQuad'
            });
        });
        
        img.addEventListener('mouseleave', function() {
            anime({
                targets: this,
                scale: 1,
                duration: 300,
                easing: 'easeOutQuad'
            });
        });
    });
}

// Utility functions
function showNotification(message, type = 'info') {
    // Create notification element
    const notification = document.createElement('div');
    notification.className = `fixed top-4 right-4 z-50 p-4 rounded-lg shadow-lg max-w-sm transform translate-x-full transition-transform`;
    
    // Set colors based on type
    const colors = {
        success: 'bg-green-500 text-white',
        warning: 'bg-yellow-500 text-white',
        error: 'bg-red-500 text-white',
        info: 'bg-blue-500 text-white'
    };
    
    notification.className += ` ${colors[type] || colors.info}`;
    notification.textContent = message;
    
    document.body.appendChild(notification);
    
    // Animate in
    setTimeout(() => {
        notification.style.transform = 'translateX(0)';
    }, 100);
    
    // Animate out and remove
    setTimeout(() => {
        notification.style.transform = 'translateX(100%)';
        setTimeout(() => {
            document.body.removeChild(notification);
        }, 300);
    }, 3000);
}

// Mobile menu toggle
function toggleMobileMenu() {
    const mobileMenu = document.getElementById('mobile-menu');
    const isOpen = mobileMenu.classList.contains('hidden');
    
    if (isOpen) {
        mobileMenu.classList.remove('hidden');
        anime({
            targets: mobileMenu,
            opacity: [0, 1],
            translateY: [-20, 0],
            duration: 300,
            easing: 'easeOutExpo'
        });
    } else {
        anime({
            targets: mobileMenu,
            opacity: [1, 0],
            translateY: [0, -20],
            duration: 300,
            easing: 'easeOutExpo',
            complete: () => {
                mobileMenu.classList.add('hidden');
            }
        });
    }
}

// Smooth scroll to section
function scrollToSection(sectionId) {
    const section = document.getElementById(sectionId);
    if (section) {
        section.scrollIntoView({
            behavior: 'smooth',
            block: 'start'
        });
    }
}

// Initialize testimonials slider
function initializeTestimonials() {
    const testimonials = document.querySelectorAll('.testimonial');
    let currentIndex = 0;
    
    function showTestimonial(index) {
        testimonials.forEach((testimonial, i) => {
            if (i === index) {
                testimonial.style.display = 'block';
                anime({
                    targets: testimonial,
                    opacity: [0, 1],
                    translateY: [20, 0],
                    duration: 500,
                    easing: 'easeOutExpo'
                });
            } else {
                testimonial.style.display = 'none';
            }
        });
    }
    
    function nextTestimonial() {
        currentIndex = (currentIndex + 1) % testimonials.length;
        showTestimonial(currentIndex);
    }
    
    // Initialize first testimonial
    if (testimonials.length > 0) {
        showTestimonial(0);
        setInterval(nextTestimonial, 5000);
    }
}

// Call testimonial initialization if testimonials exist
document.addEventListener('DOMContentLoaded', function() {
    if (document.querySelectorAll('.testimonial').length > 0) {
        initializeTestimonials();
    }
});